package main.GUIC;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;

public class GameListPaneController extends MainPanelController implements Initializable {
	@FXML GridPane gridPane;
	@FXML ImageView imageView;

	@Override
	public void initialize(URL location, ResourceBundle resources) { 
		setControls();
	}

	private void setControls() {
		subController.setupGameListPanePanel(imageView);
	}
}
