package main.GUIC.mainPaneGUIC;

import javafx.fxml.FXML;
import javafx.scene.image.ImageView;
import main.ImageLoader;
/**
 * ImageViewのコントローラ 
 * 画像をゲームリストから読み込んで表示する
 * @author Taishin
 */
public class ImageViewC implements MainPanelIController {
	@FXML private ImageView imageView;
	/**
	 * 画像の大きさ
	 */
	private static final int IMAGE_SIZE = 100;

	public ImageViewC(ImageView imageView, MainPanelSubject subController) {
		this.imageView = imageView;
		subController.registerObserver(this);
	}

	@Override
	public void setup() {
		imageView.autosize();
//		
//		以下、読み込みの確認
//		
		/*imageView.setImage(new Image("application/BlueBackCloser.png"));
		imageView.setFitWidth(IMAGE_SIZE);
		imageView.setPreserveRatio(true);
		imageView.setSmooth(true);
		imageView.setCache(true);*/
	}

	@Override
	public void reset() {
		String imagePath = gameList.getImagePath();
		imageView.autosize();
		if(imagePath == null) {
//			「画像が見つかりません」等の画像を表示する予定
//			現在は何も表示していない
//			imageView.setImage(new Image(""));
		} else {
			imageView.setImage(ImageLoader.getImages(imagePath));
			imageView.setFitWidth(IMAGE_SIZE);
			imageView.setPreserveRatio(true);
			imageView.setSmooth(true);
			imageView.setCache(true);
		}
	}

}
