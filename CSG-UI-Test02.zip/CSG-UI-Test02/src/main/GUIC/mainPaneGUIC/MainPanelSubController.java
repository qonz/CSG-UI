package main.GUIC.mainPaneGUIC;

import java.util.ArrayList;

import main.GUIC.IController;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.MenuItem;
import javafx.scene.image.ImageView;

/**
 * MainPanel SubController
 * 
 * @author mayoineko
 *
 */
public class MainPanelSubController implements MainPanelSubject {
	private static MainPanelSubject subController = new MainPanelSubController();
	private ArrayList<IController> observers;
	//Controllers
	private HowToUseC howToUseC;
	private QuitC quitC;
	private AddFileC addFileC;
	
	private CanvasC canvasC;
//	private ScrollPaneC scrollPaneC;
	
	private ImageViewC imageViewC;
//	private ExeButtonC exeButtonC;
//	private GameListViewC gameListViewC;
//	private GenreBoxC genreBoxC;
	/**
	 * initialize observers
	 * observers初期化
	 */
	private MainPanelSubController() {
		observers = new ArrayList<IController>();
	}
	/**
	 * Instance of this class
	 * 唯一のインスタンス
	 * @return
	 */
	public static MainPanelSubController getInstance() {
		return (MainPanelSubController)subController;
	}
	/**
	 * set Controls of MainPanel.fxml
	 * MainPanel.fxmlの部品を定義する
	 * @param controls
	 */
	public void setupMainPanel(Object... controls) {
		// MenuItem
		addFileC = new AddFileC((MenuItem)controls[0],subController);
		addFileC.setup();
		quitC = new QuitC((MenuItem)controls[1]);
		quitC.setup();
		howToUseC = new HowToUseC((MenuItem)controls[2]);
		howToUseC.setup();
		// CheckMenuItem
//		resizableC = new ResizableC((CheckMenuItem)controls[2]);
//		resizableC.setup();
	}
	/**
	 * set Controls of GameListPanel.fxml
	 * GameListPanel.fxmlの部品を定義する
	 * 
	 * @param controls
	 */
	public void setupGameListPanePanel(Object... controls) {
		imageViewC = new ImageViewC((ImageView)controls[0], subController);
		imageViewC.setup();
		imageViewC.reset();
		// ComboBox<Genre>
//		genreBoxC = new GenreBoxC((ComboBox<Genre>)controls[0], subController);
//		genreBoxC.setup();
		// ListView<String>
//		gameListViewC = new GameListViewC((ListView<String>)controls[1], subController);
//		gameListViewC.setup();
		// Button
//		exeButtonC = new ExeButtonC((Button)controls[2]);
//		exeButtonC.setup();
	}
	/**
	 * set Controls of DetailPanel.fxml
	 * DetailPanel.fxmlの部品を定義する
	 * @param controls
	 */
	public void setupDetailPanel(Object...controls) {
		canvasC = new CanvasC((Canvas)controls[0], subController);
		canvasC.setup();
//		scrollPaneC = new ScrollPaneC((ScrollPane)controls[1], subController);
//		scrollPaneC.setup();
	}
	@Override
	public void registerObserver(IController c) {
		observers.add(c);
	}
	@Override
	public void notifyObservers() {
		for(int i=0;i<observers.size();i++) {
			MainPanelIController observer = (MainPanelIController)observers.get(i);
			observer.reset();
		}
	}
	@Override
	public void removeObserver(IController c) {
		int i= observers.indexOf(c);
		if (i>=0)
			observers.remove(i);
	}
}
