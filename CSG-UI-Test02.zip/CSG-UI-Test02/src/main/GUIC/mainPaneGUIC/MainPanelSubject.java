package main.GUIC.mainPaneGUIC;

import main.GUIC.Subject;



interface MainPanelSubject extends Subject {
}
