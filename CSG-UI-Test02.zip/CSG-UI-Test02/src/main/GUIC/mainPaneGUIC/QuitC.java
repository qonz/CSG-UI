package main.GUIC.mainPaneGUIC;

import javafx.fxml.FXML;
import javafx.scene.control.MenuItem;

public class QuitC implements MainPanelIController {
	@FXML MenuItem quitC;
	
	public QuitC(MenuItem quitC){
		this.quitC = quitC;
	}

	@Override
	public void setup() {
		quitC.setOnAction(evt -> System.exit(0));
	}

	@Override
	public void reset() {}

}
