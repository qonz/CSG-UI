package main.GUIC;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import main.GUIC.mainPaneGUIC.MainPanelSubController;
/**
 * MainPanelのコントローラ
 * 実際の処理はMainPanelSubControllerで定義
 * @author Taishin
 * 
 */
public class MainPanelController implements Initializable{
	/** FXML */
	@FXML private MenuItem addFile;
	@FXML private MenuItem quit;
	@FXML private MenuItem howTo;
	@FXML private AnchorPane allPane;
	@FXML private AnchorPane shootingPane;
	@FXML private AnchorPane actionPane;
	@FXML private AnchorPane adventurePane;
	@FXML private AnchorPane simulationPane;
	@FXML private AnchorPane rpgPane;
	@FXML private AnchorPane puzzlePane;
	@FXML private AnchorPane tablegamePane;
	@FXML private AnchorPane othersPane;
	
	/** SubController **/
	protected MainPanelSubController subController = MainPanelSubController.getInstance();

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		setControls();
		setMainPane();
		System.out.println("MainPanelController OK");		
	}

	/**
	 * メニューバーに置く項目(item)を設定
	 */
	private void setControls() {
		subController.setupMainPanel(addFile, quit, howTo);
	}
	
	/**
	 * 他のパネルを読み込む
	 */
	private void setMainPane(){
		//GameListPanel.fxmlを追加
		try {
			VBox gameListPane = (VBox)FXMLLoader.load(getClass().getClassLoader().getResource("fxml/main/GameListPanel.fxml"));
			allPane.getChildren().add(gameListPane);
		} catch(IOException e) {
			System.err.println("Can't be read 'GameListPanel.fxml'.");
		}
		try {
			VBox gameListPane = (VBox)FXMLLoader.load(getClass().getClassLoader().getResource("fxml/main/GameListPanel.fxml"));
			shootingPane.getChildren().add(gameListPane);
		} catch(IOException e) {
			System.err.println("Can't be read 'GameListPanel.fxml'.");
		}
		try {
			VBox gameListPane = (VBox)FXMLLoader.load(getClass().getClassLoader().getResource("fxml/main/GameListPanel.fxml"));
			actionPane.getChildren().add(gameListPane);
		} catch(IOException e) {
			System.err.println("Can't be read 'GameListPanel.fxml'.");
		}
		try {
			VBox gameListPane = (VBox)FXMLLoader.load(getClass().getClassLoader().getResource("fxml/main/GameListPanel.fxml"));
			adventurePane.getChildren().add(gameListPane);
		} catch(IOException e) {
			System.err.println("Can't be read 'GameListPanel.fxml'.");
		}
		try {
			VBox gameListPane = (VBox)FXMLLoader.load(getClass().getClassLoader().getResource("fxml/main/GameListPanel.fxml"));
			simulationPane.getChildren().add(gameListPane);
		} catch(IOException e) {
			System.err.println("Can't be read 'GameListPanel.fxml'.");
		}
		try {
			VBox gameListPane = (VBox)FXMLLoader.load(getClass().getClassLoader().getResource("fxml/main/GameListPanel.fxml"));
			rpgPane.getChildren().add(gameListPane);
		} catch(IOException e) {
			System.err.println("Can't be read 'GameListPanel.fxml'.");
		}
		try {
			VBox gameListPane = (VBox)FXMLLoader.load(getClass().getClassLoader().getResource("fxml/main/GameListPanel.fxml"));
			puzzlePane.getChildren().add(gameListPane);
		} catch(IOException e) {
			System.err.println("Can't be read 'GameListPanel.fxml'.");
		}
		try {
			VBox gameListPane = (VBox)FXMLLoader.load(getClass().getClassLoader().getResource("fxml/main/GameListPanel.fxml"));
			tablegamePane.getChildren().add(gameListPane);
		} catch(IOException e) {
			System.err.println("Can't be read 'GameListPanel.fxml'.");
		}
		try {
			VBox gameListPane = (VBox)FXMLLoader.load(getClass().getClassLoader().getResource("fxml/main/GameListPanel.fxml"));
			othersPane.getChildren().add(gameListPane);
		} catch(IOException e) {
			System.err.println("Can't be read 'GameListPanel.fxml'.");
		}
		
		//icon.fxmlを追加
/*		try {
			HBox iconPane = (HBox)FXMLLoader.load(getClass().getClassLoader().getResource("fxml/main/icon.fxml"));
			mainPane.getChildren().add(iconPane);
		} catch(IOException e) {
			System.err.println("Can't be read 'icon.fxml'.");
		}*/
	}
}
