package main.GUIC.addgamePaneGUIC;

import main.Register;
import main.GUIC.IController;

public interface AddFilePanelIController extends IController {
	public final static Register register = new Register();
}
