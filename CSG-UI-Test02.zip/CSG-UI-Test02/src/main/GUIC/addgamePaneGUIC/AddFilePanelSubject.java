package main.GUIC.addgamePaneGUIC;

import main.GUIC.Subject;

public interface AddFilePanelSubject extends Subject{

}
