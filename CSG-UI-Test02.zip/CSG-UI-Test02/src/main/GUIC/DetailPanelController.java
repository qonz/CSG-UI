package main.GUIC;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
/**
 * DetailPanelController
 * 
 * @author Taishin
 * 
 */
public class DetailPanelController extends MainPanelController implements Initializable{
	/** FXML */
	@FXML private Canvas detailImage;
	@FXML private Pane title;
	@FXML private Pane howTo;
	@FXML private Pane creater;
	@FXML private Pane year;
	@FXML private Label back;
	
	@Override
	public void initialize(URL url, ResourceBundle rb) {
		setControls();
		System.out.println("DetailPanelController OK");
	}
	
	private void setControls() {
		subController.setupDetailPanel(detailImage, title, howTo, creater, year, back);
	}
}
