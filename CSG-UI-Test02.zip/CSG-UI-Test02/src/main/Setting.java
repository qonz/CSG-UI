package main;

/**
 * 設定クラス
 * @author mayoineko, Taishin
 *
 */
public class Setting {
	private final static Configuration conf = Configuration.getConfiguration();
	/** Title */
	public final static String TITLE 
			= conf.getStringProperty("Title");
	/** stageの最小幅 */
	public final static double MIN_WIDTH = 1280;
	/** stageの最小高さ(TitleBar値22) */
	public final static double MIN_HEIGHT = 720;
	/** FullScreen設定 */
	public static boolean isFullScr = false;
	/** stageのresize設定 */
	public static boolean isResiza = false;
	/** GameFolderPath*/
	public final static String GAMEFOLDER_PATH 
			= conf.getStringProperty("GameFolder_Path");
	/** SettingFolderPath */
	public final static String SETTING_FOLDER_PATH 
			= conf.getStringProperty("SettingFolder_Path");
	/** Windowsのドライブ設定**/
	public final static String Drive
			= conf.getStringProperty("Drive");
}
