package application;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.canvas.Canvas;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;

public class IconC_test implements Initializable {
	@FXML private Canvas canvas;
	@FXML private AnchorPane anchorPane;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO 自動生成されたメソッド・スタブ
		anchorPane.setOnMouseClicked(evt -> {
			try {
				HBox detailPane = (HBox)FXMLLoader.load(getClass().getClassLoader().getResource("application/Detail_test.fxml"));
				anchorPane.getChildren().add(detailPane);
			} catch(IOException e) {
				System.err.println("Can't be read 'Detail.fxml'.");
			}
		});
	}

}
