package application;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;

public class MainPanelC_test implements Initializable{
	@FXML private AnchorPane anchorPane;
	@FXML private TilePane tilePane;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO 自動生成されたメソッド・スタブ
		setMainPane();
	}
	
	private void setMainPane(){
	//Detail.fxmlを追加
	try {
		HBox detailPane = (HBox)FXMLLoader.load(getClass().getClassLoader().getResource("application/Detail_test.fxml"));
		anchorPane.getChildren().add(detailPane);
	} catch(IOException e) {
		System.err.println("Can't be read 'Detail.fxml'.");
	}
	//icon.fxmlを追加予定
		try {
		VBox iconPane = (VBox)FXMLLoader.load(getClass().getClassLoader().getResource("application/Icon_test.fxml"));
		tilePane.getChildren().add(iconPane);
	} catch(IOException e) {
		System.err.println("Can't be read 'icon.fxml'.");
	}
}
}
